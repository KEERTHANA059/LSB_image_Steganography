#include <stdio.h>
#include<string.h>
#include "decode.h"
#include "types.h"
#include "common.h"

// Function Definitions  to read and validate cla arguments
Status read_and_validate_decode_args(char *argv[], DecodeInfo *decInfo)
{
    //check if the argument[2] is .bmp file or not
	if (strcmp(strstr ( argv[2],"."),".bmp") == e_success ) 
	{
	   decInfo->stego_image_fname=argv[2];
	}
	else
	{
	    return e_failure;
	 }
	//check if the argument[3] is .txt or not
	if ( argv[3] != NULL )
	{
	    if (strcmp(strstr ( argv[2],"."),".txt") == e_success )
	    {
	        decInfo->secret_fname=argv[3];
	    }
	    else
	        return e_failure;
	}
	//if argument[3] isn't present then create one
	else
	{
	        decInfo->secret_fname="decoded_file.txt"; 
	}
	return e_success;
}
//Function to open the files useing file handling
Status open_decode_files(DecodeInfo *decInfo)
{
     decInfo->fptr_stego_image = fopen(decInfo->stego_image_fname, "r"); //<- open stego file in read mode
    // Do Error handling
    if (decInfo->fptr_stego_image == NULL)     //<- check if file is null or not
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", decInfo->stego_image_fname); 

        return e_failure;
    }
    decInfo->fptr_secret= fopen(decInfo->secret_fname,"w");  //<- open txt file in write mode to store secret file data
    if (decInfo->fptr_secret == NULL)     
    {
        perror("fopen");			//<- check if file can be opened or not
        fprintf(stderr, "ERROR: Unable to open file %s\n", decInfo->secret_fname);

        return e_failure;
    }
    return e_success;
}
//Funtion to decode magic strings 
Status decode_magic_string( char *magic_string, DecodeInfo *decInfo)
{
    //as magic string starts from 54 th block of bytes jump to 54th byte
    fseek(decInfo->fptr_stego_image,54,SEEK_SET);  
    if(decode_data_from_image(magic_string, strlen(magic_string) ,decInfo->fptr_stego_image,decInfo)==e_success)
    {
        return e_success;
     }
    else
        return e_failure;
}
//Funtion to decode the data from image
Status decode_data_from_image(char *data, int size, FILE *fptr_stego_image,DecodeInfo *decInfo)
{
    char str[8];
    for(int i=0;i<size;i++)
    {
        fread(str,sizeof(char),8,decInfo->fptr_stego_image);
        
        //call byte from lsb to get all lsb to get the character
        decode_byte_from_lsb(str,i,8,decInfo);
        if(decInfo->image_buffer [i] != data[i] )
        {
            return e_failure;
        }
    }
    return e_success;
}
//function to decode byte from lsb
Status decode_byte_from_lsb(char *str,int index,int datatype_size,DecodeInfo *decInfo)
{
    uint lsb,mask=0x00;
    //loop to get lsb of each byte
    for(int i=0;i<datatype_size;i++)
    {
        lsb=(str[i]&0x01);
        mask=mask | (lsb<<(datatype_size-1-i));
    }
    decInfo->image_buffer[index]=mask;
}
//function to decode secret file extension size
Status decode_secret_file_extn_size(DecodeInfo *decInfo)
{
    char file_size[32];
    //as integer will be stored in 32byte take 32 bytes to decode 
    fread(file_size,sizeof(char),32,decInfo->fptr_stego_image);
    decode_byte_from_lsb(file_size,0,32,decInfo);
    
    if(decInfo->size_extn_file=decInfo->image_buffer[0])
    {
        return e_success;
    }
    else
        return e_failure; 
}
//function to decode secret file extension
Status decode_secret_file_extn(DecodeInfo *decInfo)
{
    char str[4]=".txt";
    if(decode_data_from_image(str,strlen(str) ,decInfo->fptr_stego_image,decInfo)==e_success)
    {
    return e_success;
    }
}
//function to decode secret file size
Status decode_secret_file_size( DecodeInfo *decInfo)
{
     char file_size[32];
    fread(file_size,sizeof(char),32,decInfo->fptr_stego_image);
    decode_byte_from_lsb(file_size,0,32,decInfo);
    if(decInfo->size_secret_file=decInfo->image_buffer[0])
    {
        return e_success;
    }
    else
        return e_failure; 
}
//function to decode secret file data
Status decode_secret_file_data(DecodeInfo *decInfo)
{
    char ch[8];
    for (int i = 0; i < decInfo->size_secret_file; i++)
    {
        fread(ch,sizeof(char),8,decInfo->fptr_stego_image);
           uint lsb,mask=0x00;
            for(int i=0;i<8;i++)
            {
                lsb=(ch[i]&0x01);
                mask=mask | (lsb<<(7-i));
            }
            //print all the data to decode file txt
            fputc(mask,decInfo->fptr_secret);
    }
    return e_success;
}
//function to do decoding
Status do_decoding(DecodeInfo *decInfo)
{
    //<- check if files opening ot not
    if ( open_decode_files(decInfo) == e_success)  
    {
        printf("Opening files to decode is successful\n");
        //<- check if magic string decoded or not
        if( decode_magic_string( MAGIC_STRING , decInfo )==e_success) 
        {
            printf("Magic string decoded successfully\n");
            //<- check if file extension size decoded or not
            if( decode_secret_file_extn_size(decInfo)== e_success) 
            {
                printf("Secret file extension size is decoded successfully\n");     
                //<- check if extension decoded or not
                if (decode_secret_file_extn(decInfo) == e_success)  
                {
                    printf("Secret file extension size is decoded successfully\n");
                     //<- check if secret data size decoded or not
                    if(decode_secret_file_size(decInfo)==e_success) 
                    {
                        printf("Secret file size is decoded successfully\n");
                        //<- check if secret file data decoded or not
                        if ( decode_secret_file_data(decInfo) == e_success) 
                        {
                            printf("Secret file data is decoded successfully\n");
                        }
                        else
                        {
                             printf("Secret file data decode is failed\n");
                            return e_failure;
                        }
                    }
                    else
                    {
                        printf("Secret file size decode is failed\n");
                        return e_failure;
                    }
                }
                else
                {
                    printf("Secret file extension size decode is failed\n");
                    return e_failure;
                }
            }
            else
            {
                printf("Secret file extension size decod is failed\n");
            }
        }
        else
        {
            printf("Decoding magic string is failed\n");
            return e_failure;
        }
    }
    else
    {
        printf("Opening files to decode is failed\n");
        return e_failure;
    }
    return e_success;
}
